def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

print("Addition:", add(3, 4))
print("Subtraction:", subtract(10, 5))
